# Elaborating course-of-values induction in Cedille: code artifact

## Listing

You can find a listing and description of all code files in this repo in
[Everything.ced](./Everything.ced)

## Elaborating files

You will need to install the latest version of Cedille. Check the instructions
on the official website: https://cedille.github.io/#installation . Once
Cedille is installed, you can test elaboration yourself by checking
[examples/Div.ced](./examples/Div.ced) with `M-s` (that's Alt+s for
non-Emacsers) and specify a directory for elaboration. A pre-elaborated version
of division is also provided.

Note that the results of elaboration Cedille actually implements is a somewhat
different from the process presented in the paper. For example:
- in `divide`, `mu` is `Nat-IndFixM`
- in `ite`, `sigma` is `IndF-bool`

We chose to present in the paper a process of elaboration that was more
pedagogical than the process implemented by Cedille, which prioritizes brevity
in the derivation of induction for the datatype signature and has a good deal
more typing annotations.

